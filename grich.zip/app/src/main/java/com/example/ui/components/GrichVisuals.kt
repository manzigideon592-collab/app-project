package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Procedurally draws the custom "GRICH" emblem:
 * A stylized G symbol integrated with an elegant Christian cross inside.
 */
@Composable
fun GrichLogoGraphic(
    modifier: Modifier = Modifier,
    primaryColor: Color = Color(0xFFC084FC), // light purple
    secondaryColor: Color = Color(0xFF8B5CF6), // deeper violet
    glowColor: Color = Color(0x3F8B5CF6)
) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val minDim = kotlin.math.min(width, height)
        val strokeWidthValue = minDim * 0.12f
        val center = Offset(width / 2f, height / 2f)

        // Draw background subtle glow
        drawCircle(
            color = glowColor,
            radius = minDim * 0.55f,
            center = center
        )

        // Gradient for the G shape
        val gradientBrush = Brush.linearGradient(
            colors = listOf(primaryColor, secondaryColor),
            start = Offset(0f, 0f),
            end = Offset(width, height)
        )

        // Draw outer 'G' loop
        val arcRadius = minDim * 0.38f
        drawArc(
            brush = gradientBrush,
            startAngle = 35f,
            sweepAngle = 290f,
            useCenter = false,
            topLeft = Offset(center.x - arcRadius, center.y - arcRadius),
            size = Size(arcRadius * 2, arcRadius * 2),
            style = Stroke(width = strokeWidthValue, cap = StrokeCap.Round)
        )

        // Draw 'G' stem/shelf pointing inwards
        val stemStart = Offset(
            center.x + arcRadius * kotlin.math.cos(Math.toRadians(35.0)).toFloat(),
            center.y + arcRadius * kotlin.math.sin(Math.toRadians(35.0)).toFloat()
        )
        val stemEnd = Offset(center.x + arcRadius * 0.3f, center.y + arcRadius * 0.45f)
        
        // Horizontal bar of G bar
        drawLine(
            brush = gradientBrush,
            start = Offset(center.x + arcRadius * 0.3f, center.y + arcRadius * 0.45f),
            end = Offset(center.x + arcRadius * 0.85f, center.y + arcRadius * 0.45f),
            strokeWidth = strokeWidthValue,
            cap = StrokeCap.Round
        )

        // Draw centered Cross inside the 'G'
        val crossWidth = minDim * 0.08f
        val crossHeight = minDim * 0.42f
        val crossHeadSize = minDim * 0.28f

        // 1. Vertical post of the Cross
        drawRoundRect(
            brush = gradientBrush,
            topLeft = Offset(center.x - crossWidth / 2f, center.y - crossHeight * 0.48f),
            size = Size(crossWidth, crossHeight),
            cornerRadius = CornerRadius(crossWidth / 2f, crossWidth / 2f)
        )

        // 2. Horizontal crossbar
        drawRoundRect(
            brush = gradientBrush,
            topLeft = Offset(center.x - crossHeadSize / 2f, center.y - crossHeight * 0.20f),
            size = Size(crossHeadSize, crossWidth),
            cornerRadius = CornerRadius(crossWidth / 2f, crossWidth / 2f)
        )
    }
}

/**
 * Animated sound equalizers wave visualizer.
 * Generates rhythmic breathing bars using continuous spring/sine tween functions.
 */
@Composable
fun AudioWavesVisualizer(
    modifier: Modifier = Modifier,
    barCount: Int = 12,
    barColor: Color = Color(0xFFC084FC),
    baseHeight: Dp = 48.dp,
    barWidth: Dp = 4.dp,
    spacing: Dp = 3.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "audio_waves")

    // We can generate animated heights for each bar
    val heights = (0 until barCount).map { index ->
        val duration = 600 + (index % 4) * 200
        val delay = index * 100
        val animFloat by infiniteTransition.animateFloat(
            initialValue = 0.15f,
            targetValue = 0.95f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = duration, delayMillis = delay),
                repeatMode = RepeatMode.Reverse
            ),
            label = "bar_$index"
        )
        animFloat
    }

    Row(
        modifier = modifier.height(baseHeight),
        horizontalArrangement = Arrangement.spacedBy(spacing),
        verticalAlignment = Alignment.CenterVertically
    ) {
        heights.forEach { scale ->
            Spacer(
                modifier = Modifier
                    .width(barWidth)
                    .fillMaxHeight(scale)
                    .backgroundGradientPill(barColor)
            )
        }
    }
}


// Custom modifier helper to give a beautiful pill shape and vertical gradient to the EQ bars
fun Modifier.backgroundGradientPill(color: Color): Modifier = this.then(
    Modifier
        .clip(CircleShape)
        .background(
            Brush.verticalGradient(
                colors = listOf(
                    color.copy(alpha = 0.95f),
                    color.copy(alpha = 0.45f)
                )
            )
        )
)
