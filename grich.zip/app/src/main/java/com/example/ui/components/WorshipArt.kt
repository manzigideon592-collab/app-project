package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Track

fun parseHexColor(hexString: String): Color {
    return try {
        val clean = if (hexString.startsWith("#")) hexString.substring(1) else hexString
        val colorInt = android.graphics.Color.parseColor("#$clean")
        Color(colorInt)
    } catch (_: Exception) {
        Color(0xFF8B5CF6) // violet fallback
    }
}

@Composable
fun WorshipAlbumArt(
    track: Track,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 16.dp,
    showTextOverlay: Boolean = true
) {
    val startColor = parseHexColor(track.coverGradientStart)
    val endColor = parseHexColor(track.coverGradientEnd)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                Brush.linearGradient(
                    colors = listOf(startColor, endColor),
                    start = Offset(0f, 0f),
                    end = Offset(1f, 1f)
                )
            )
            .border(1.dp, Color(0x3FBF97FF), RoundedCornerShape(cornerRadius)),
        contentAlignment = Alignment.Center
    ) {
        // Procedural Custom artwork details based on type
        when (track.customIconType) {
            "spotlight" -> SpotlightBeamOverlay()
            "cross_ring" -> CrossRingOverlay()
            "water_ripple" -> WaterRippleOverlay()
            "vertical_beams" -> VerticalBeamsOverlay()
            else -> CrossRingOverlay()
        }

        // Display custom artistic typography overlays if requested
        if (showTextOverlay) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = track.title.uppercase(),
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    letterSpacing = 2.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 17.sp
                )
                Text(
                    text = track.artist,
                    color = Color(0xBFFFFFFF),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Light,
                    fontFamily = FontFamily.Serif,
                    letterSpacing = 1.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun SpotlightBeamOverlay() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Spotlight beam pathway
        val path = Path().apply {
            moveTo(w / 2f, 0f)
            lineTo(w * 0.15f, h)
            lineTo(w * 0.85f, h)
            close()
        }

        // Draw translucent gold beam shining down
        drawPath(
            path = path,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0x7FDFB05B), Color(0x05DFB05B)),
                startY = 0f,
                endY = h
            )
        )

        // Subtle overhead beam lines
        drawLine(
            color = Color(0x3FDFB05B),
            start = Offset(w / 2f, 0f),
            end = Offset(w * 0.20f, h),
            strokeWidth = 1.5f
        )
        drawLine(
            color = Color(0x3FDFB05B),
            start = Offset(w / 2f, 0f),
            end = Offset(w * 0.80f, h),
            strokeWidth = 1.5f
        )
    }
}

@Composable
fun CrossRingOverlay() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val sizeRef = kotlin.math.min(w, h)

        // Neon glowing circle ring
        drawCircle(
            color = Color(0x4FA855F7),
            radius = sizeRef * 0.35f,
            style = Stroke(width = sizeRef * 0.04f)
        )
        drawCircle(
            color = Color(0x1FBF83FC),
            radius = sizeRef * 0.37f,
            style = Stroke(width = sizeRef * 0.08f)
        )

        // Draw subtle centered Cross
        val crossWidth = sizeRef * 0.05f
        val crossHeight = sizeRef * 0.38f
        val crossHeadSize = sizeRef * 0.24f

        val center = Offset(w / 2f, h / 2f)

        // Vertical
        drawRoundRect(
            color = Color(0xBFFAF5FF),
            topLeft = Offset(center.x - crossWidth / 2f, center.y - crossHeight / 2f),
            size = Size(crossWidth, crossHeight),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(crossWidth / 2f, crossWidth / 2f)
        )

        // Horizontal
        drawRoundRect(
            color = Color(0xBFFAF5FF),
            topLeft = Offset(center.x - crossHeadSize / 2f, center.y - crossHeight * 0.15f),
            size = Size(crossHeadSize, crossWidth),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(crossWidth / 2f, crossWidth / 2f)
        )
    }
}

@Composable
fun WaterRippleOverlay() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val sizeRef = kotlin.math.min(w, h)
        val center = Offset(w / 2f, h * 0.55f)

        // Concentric expanding ring paths representing watery ocean steps
        drawCircle(
            color = Color(0x2FABC3EE),
            center = center,
            radius = sizeRef * 0.25f,
            style = Stroke(width = 1.dp.toPx())
        )
        drawCircle(
            color = Color(0x1FABC3EE),
            center = center,
            radius = sizeRef * 0.38f,
            style = Stroke(width = 1.5.dp.toPx())
        )
        drawCircle(
            color = Color(0x0FABC3EE),
            center = center,
            radius = sizeRef * 0.50f,
            style = Stroke(width = 2.dp.toPx())
        )
    }
}

@Composable
fun VerticalBeamsOverlay() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Ascending glow rays
        val raysCount = 5
        val baseWidth = w / (raysCount * 2)

        for (i in 0 until raysCount) {
            val progress = i / (raysCount - 1).toFloat()
            val xStart = w * 0.2f + progress * w * 0.6f
            val path = Path().apply {
                moveTo(xStart, h)
                lineTo(xStart - baseWidth * 1.5f, 0f)
                lineTo(xStart + baseWidth * 1.5f, 0f)
                close()
            }
            drawPath(
                path = path,
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0x3FFFFFFF), Color(0x01FFFFFF)),
                    startY = h,
                    endY = 0f
                )
            )
        }
    }
}

/**
 * Styled circular badge depicting the playlist visual icon:
 * A stylized ring centering a giant white Cross with premium atmospheric purple glow.
 */
@Composable
fun WorshipPlaylistCircularArt(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF2E1065), Color(0xFF030107)),
                    radius = 240f
                )
            )
            .border(
                width = 2.dp,
                brush = Brush.sweepGradient(
                    colors = listOf(Color(0xFFC084FC), Color(0xFF8B5CF6), Color(0xFFC084FC))
                ),
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val minDim = kotlin.math.min(w, h)
            val center = Offset(w / 2f, h / 2f)

            // Dynamic glow ring
            drawCircle(
                color = Color(0x8F8B5CF6),
                radius = minDim * 0.35f,
                style = Stroke(width = minDim * 0.05f)
            )

            // Giant cross
            val crossW = minDim * 0.07f
            val crossH = minDim * 0.50f
            val headW = minDim * 0.30f

            // Post
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(center.x - crossW / 2f, center.y - crossH / 2f),
                size = Size(crossW, crossH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(crossW / 2f, crossW / 2f)
            )

            // Arms
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(center.x - headW / 2f, center.y - crossH * 0.16f),
                size = Size(headW, crossW),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(crossW / 2f, crossW / 2f)
            )
        }
    }
}
