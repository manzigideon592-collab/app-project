package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Track
import com.example.ui.TrackViewModel
import com.example.ui.components.WorshipPlaylistCircularArt
import com.example.ui.components.WorshipAlbumArt

@Composable
fun PlaylistScreen(
    viewModel: TrackViewModel,
    category: String,
    playlistTitle: String,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allTracks by viewModel.allTracks.collectAsState()
    
    // Filter tracks belonging to this specific playlist category
    val playlistTracks = remember(category, allTracks) {
        if (category == "ALL") {
            allTracks
        } else {
            allTracks.filter { it.category.uppercase() == category.uppercase() }
        }
    }

    var isBookmarked by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        bottomBar = {
            Column {
                // Persistent bottom overlay controls
                MiniPlayerBar(viewModel = viewModel, onExpand = { viewModel.playTrack(it, playlistTracks) })
                
                // Fixed spacer because bottom nav is shown on main dashboard
                Spacer(modifier = Modifier.windowInsetsBottomHeight(WindowInsets.navigationBars))
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("playlist_category_screen")
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Top bar actions
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackClick, modifier = Modifier.testTag("playlist_back_btn")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to dashboard",
                            tint = Color.White
                        )
                    }

                    Row {
                        IconButton(onClick = { isBookmarked = !isBookmarked }, modifier = Modifier.testTag("playlist_fav_btn")) {
                            Icon(
                                imageVector = if (isBookmarked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Favorite Playlist",
                                tint = if (isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground
                            )
                        }
                        IconButton(onClick = { /* Share playlist option */ }) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Share",
                                tint = Color.White
                            )
                        }
                    }
                }
            }

            // 2. Circular Glowing Worship Icon Cover
            item {
                WorshipPlaylistCircularArt(
                    modifier = Modifier
                        .size(175.dp)
                        .padding(vertical = 12.dp)
                        .testTag("playlist_circular_art")
                )
            }

            // 3. Playlist Header & Descriptions
            item {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = playlistTitle,
                        color = MaterialTheme.colorScheme.onBackground,
                        style = MaterialTheme.typography.titleLarge,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Playlist by GRICH",
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.labelLarge.copy(
                            letterSpacing = 1.sp
                        )
                    )

                    Text(
                        text = "${playlistTracks.size} Songs  •  3h 45m",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Timeless worship songs to draw\nyou closer to His presence.",
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontFamily = FontFamily.Serif,
                            textAlign = TextAlign.Center,
                            lineHeight = 20.sp
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }

            // 4. Centered Pill Action: Shuffle Play button
            item {
                Button(
                    onClick = {
                        if (playlistTracks.isNotEmpty()) {
                            // Play randomly or shuffle starting with the first
                            val shuffled = playlistTracks.shuffled()
                            viewModel.playTrack(shuffled.first(), shuffled)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(48.dp)
                        .testTag("shuffle_play_button")
                        .padding(vertical = 2.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    shape = RoundedCornerShape(24.dp),
                    contentPadding = PaddingValues()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primary,
                                        MaterialTheme.colorScheme.secondary
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow, // Stand-in for shuffle
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Shuffle Play",
                                color = MaterialTheme.colorScheme.onPrimary,
                                style = MaterialTheme.typography.labelLarge.copy(
                                    letterSpacing = 1.sp
                                )
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(6.dp))
            }

            // 5. Vertical track lists with customized index markers (1, 2, 3...)
            itemsIndexed(playlistTracks) { index, track ->
                PlaylistSongRow(
                    index = index + 1,
                    track = track,
                    onItemClick = {
                        viewModel.playTrack(track, playlistTracks)
                    },
                    onOptionsClick = { /* Click settings toast */ }
                )
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
fun PlaylistSongRow(
    index: Int,
    track: Track,
    onItemClick: () -> Unit,
    onOptionsClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onItemClick() }
            .padding(vertical = 10.dp)
            .testTag("playlist_song_row_${track.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Aligned Index Numbers on left
        Text(
            text = index.toString(),
            color = MaterialTheme.colorScheme.tertiary,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier
                .width(28.dp)
                .padding(start = 2.dp)
        )

        // Thumbnail artwork
        WorshipAlbumArt(
            track = track,
            modifier = Modifier.size(50.dp),
            cornerRadius = 8.dp,
            showTextOverlay = false
        )

        Spacer(modifier = Modifier.width(16.dp))

        // Titles and artist descriptors
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = track.title,
                color = MaterialTheme.colorScheme.onBackground,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = track.artist,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        IconButton(onClick = onOptionsClick) {
            Icon(
                imageVector = Icons.Default.MoreVert,
                contentDescription = "Track Actions",
                tint = Color.LightGray,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
