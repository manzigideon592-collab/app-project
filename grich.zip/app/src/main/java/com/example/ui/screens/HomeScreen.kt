package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay
import com.example.data.Track
import com.example.ui.AppScreen
import com.example.ui.TrackViewModel
import com.example.ui.components.AudioWavesVisualizer
import com.example.ui.components.GrichLogoGraphic
import com.example.ui.components.WorshipAlbumArt
import com.example.ui.components.parseHexColor

@Composable
fun HomeScreen(
    viewModel: TrackViewModel,
    onPlaylistClick: (String, String) -> Unit,
    onOpenPlayer: (Track) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedTab = viewModel.selectedTab
    val recentTracks by viewModel.recentlyPlayedTracks.collectAsState()
    val favoriteTracks by viewModel.favoriteTracks.collectAsState()
    val allTracksList by viewModel.allTracks.collectAsState()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        bottomBar = {
            Column {
                // Docked Mini-Player above Bottom Navigation
                MiniPlayerBar(viewModel = viewModel, onExpand = onOpenPlayer)
                
                // M3 Standard Bottom Navigation
                AppBottomNavigationBar(
                    selectedTab = selectedTab,
                    onTabSelect = { viewModel.selectedTab = it }
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> HomeDashboardTab(
                    viewModel = viewModel,
                    recentTracks = recentTracks,
                    allTracksList = allTracksList,
                    onPlaylistClick = onPlaylistClick,
                    onSongClick = { viewModel.playTrack(it, allTracksList) }
                )
                1 -> SearchTab(
                    viewModel = viewModel,
                    onSongClick = { viewModel.playTrack(it, allTracksList) }
                )
                2 -> LibraryTab(
                    viewModel = viewModel,
                    favoriteTracks = favoriteTracks,
                    onSongClick = { viewModel.playTrack(it, favoriteTracks) }
                )
                3 -> ProfileTab()
            }
        }
    }
}

@Composable
fun HomeDashboardTab(
    viewModel: TrackViewModel,
    recentTracks: List<Track>,
    allTracksList: List<Track>,
    onPlaylistClick: (String, String) -> Unit,
    onSongClick: (Track) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_dashboard_tab")
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // 1. Header with App Logo and Actions
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "G R I C H",
                    color = MaterialTheme.colorScheme.onBackground,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 4.sp,
                        fontFamily = FontFamily.Serif
                    )
                )
                
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { /* Notifications click */ }
                        .testTag("notification_bell"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Notifications,
                        contentDescription = "Notifications",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    // Indicator dot
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.error)
                            .align(Alignment.TopEnd)
                    )
                }
            }
        }

        // 2. Beautiful Personal Greeting
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Good Morning, Faith",
                    color = MaterialTheme.colorScheme.onBackground,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }
            Text(
                text = "Start your day with worship.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // 3. Daily Worship Featured Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(135.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.surfaceVariant,
                                MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f)
                            ),
                            start = Offset(0f, 0f),
                            end = Offset(1f, 1f)
                        )
                    )
                    .clickable {
                        // Play the first track (Goodness of God)
                        if (allTracksList.isNotEmpty()) {
                            viewModel.playTrack(allTracksList.first(), allTracksList)
                        }
                    }
                    .testTag("daily_worship_card")
            ) {
                // Background artistic element
                GrichLogoGraphic(
                    modifier = Modifier
                        .size(170.dp)
                        .offset(x = 180.dp, y = (-20).dp),
                    glowColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                )

                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1.3f),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "DAILY DEVOTIONAL MIX",
                                color = MaterialTheme.colorScheme.primary,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Daily Worship",
                            color = MaterialTheme.colorScheme.onBackground,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif
                            )
                        )

                        Text(
                            text = "Play your daily mix",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .clickable {
                                if (allTracksList.isNotEmpty()) {
                                    viewModel.playTrack(allTracksList.first(), allTracksList)
                                }
                            }
                            .testTag("daily_worship_play_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        // 3.5 Worship by Spiritual Intent & Mood Grid
        item {
            MoodIntentGrid(
                onCategoryClick = onPlaylistClick
            )
        }

        // 4. Featured Playlists scrolling row
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = "Featured Playlists",
                        color = MaterialTheme.colorScheme.onBackground,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )
                    )
                    Text(
                        text = "See All",
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier
                            .clickable {
                                onPlaylistClick("WORSHIP", "Worship Essentials")
                            }
                            .testTag("featured_see_all")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(end = 12.dp)
                ) {
                    item {
                        PlaylistCard(
                            title = "All Worship",
                            count = "50 Songs",
                            gradientStart = "FF7F3DFF",
                            gradientEnd = "FF8F43EE",
                            onClick = { onPlaylistClick("WORSHIP", "Worship Essentials") }
                        )
                    }
                    item {
                        PlaylistCard(
                            title = "In His Presence",
                            count = "35 Songs",
                            gradientStart = "FF1C355E",
                            gradientEnd = "FF198754",
                            onClick = { onPlaylistClick("PEACE", "In His Presence") }
                        )
                    }
                    item {
                        PlaylistCard(
                            title = "Top Praise",
                            count = "40 Songs",
                            gradientStart = "FFFD7E14",
                            gradientEnd = "FFF35B04",
                            onClick = { onPlaylistClick("PRAISE", "Top Praise") }
                        )
                    }
                    item {
                        PlaylistCard(
                            title = "New Songs",
                            count = "10 Songs",
                            gradientStart = "FF0D6EFD",
                            gradientEnd = "FF6610F2",
                            onClick = { onPlaylistClick("ALL", "New Releases") }
                        )
                    }
                }
            }
        }

        // 5. Recently Played vertical list
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = "Recently Played",
                    color = MaterialTheme.colorScheme.onBackground,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )
                )
                Text(
                    text = "See All",
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.testTag("recently_see_all")
                )
            }
        }

        items(recentTracks.take(4)) { track ->
            SongListItem(
                track = track,
                onClick = { onSongClick(track) },
                onFavoriteToggle = { viewModel.toggleFavorite(track) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun PlaylistCard(
    title: String,
    count: String,
    gradientStart: String,
    gradientEnd: String,
    onClick: () -> Unit
) {
    val startColor = parseHexColor(gradientStart)
    val endColor = parseHexColor(gradientEnd)

    Column(
        modifier = Modifier
            .width(135.dp)
            .clickable { onClick() }
            .testTag("playlist_card_$title"),
        horizontalAlignment = Alignment.Start
    ) {
        Box(
            modifier = Modifier
                .size(135.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(startColor, endColor),
                        start = Offset(0f, 0f),
                        end = Offset(1f, 1f)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            GrichLogoGraphic(
                modifier = Modifier
                    .size(50.dp),
                glowColor = Color(0x05FFFFFF)
            )

            Text(
                modifier = Modifier.padding(bottom = 12.dp, top = 70.dp),
                text = title.uppercase(),
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                letterSpacing = 1.sp
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = title,
            color = MaterialTheme.colorScheme.onBackground,
            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = count,
            color = MaterialTheme.colorScheme.tertiary,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun SongListItem(
    track: Track,
    onClick: () -> Unit,
    onFavoriteToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 8.dp)
            .testTag("song_item_${track.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        WorshipAlbumArt(
            track = track,
            modifier = Modifier.size(54.dp),
            cornerRadius = 10.dp,
            showTextOverlay = false
        )

        Spacer(modifier = Modifier.width(16.dp))

        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = track.title,
                color = MaterialTheme.colorScheme.onBackground,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = track.artist,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        IconButton(
            onClick = { onClick() },
            modifier = Modifier.testTag("song_play_btn_${track.id}")
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Play",
                tint = MaterialTheme.colorScheme.primary
            )
        }

        IconButton(
            onClick = onFavoriteToggle,
            modifier = Modifier.testTag("song_fav_btn_${track.id}")
        ) {
            Icon(
                imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "Favorite",
                tint = if (track.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun SearchTab(
    viewModel: TrackViewModel,
    onSongClick: (Track) -> Unit
) {
    val query by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()

    val categories = listOf("WORSHIP", "PRAISE", "PEACE")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .testTag("search_tab_content")
    ) {
        Text(
            text = "Search",
            color = Color.White,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            modifier = Modifier.padding(vertical = 20.dp)
        )

        // Text Search Field
        TextField(
            value = query,
            onValueChange = { viewModel.updateSearchQuery(it) },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                .testTag("search_text_input"),
            placeholder = { Text("Songs, artists, categories...", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)) },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.primary)
            },
            trailingIcon = if (query.isNotEmpty()) {
                {
                    IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else null,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                focusedTextColor = MaterialTheme.colorScheme.onBackground,
                unfocusedTextColor = MaterialTheme.colorScheme.onBackground,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Category Badges
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            categories.forEach { cat ->
                val isActive = query.uppercase() == cat
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                        .clickable {
                            if (isActive) viewModel.updateSearchQuery("") else viewModel.updateSearchQuery(cat)
                        }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                        .testTag("category_badge_$cat"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = cat,
                        color = if (isActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }

        // Search Results List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (searchResults.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No results found for \"$query\"",
                            color = Color.LightGray,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Try filtering by Worship, Praise, or Peace",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                items(searchResults) { track ->
                    SongListItem(
                        track = track,
                        onClick = { onSongClick(track) },
                        onFavoriteToggle = { viewModel.toggleFavorite(track) }
                    )
                }
            }
        }
    }
}

@Composable
fun LibraryTab(
    viewModel: TrackViewModel,
    favoriteTracks: List<Track>,
    onSongClick: (Track) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .testTag("favorites_library_tab")
    ) {
        Text(
            text = "Your Library",
            color = Color.White,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            modifier = Modifier.padding(top = 20.dp, bottom = 4.dp)
        )
        Text(
            text = "Your bookmarked and favorited tracks.",
            color = Color(0xFFA78BFA),
            fontSize = 13.sp,
            modifier = Modifier.padding(bottom = 20.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (favoriteTracks.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.FavoriteBorder,
                            contentDescription = null,
                            tint = Color(0xFFC084FC),
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Your favorites feed is empty",
                            color = Color.LightGray,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Tap the heart icon on any track to save it here.",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                items(favoriteTracks) { track ->
                    SongListItem(
                        track = track,
                        onClick = { onSongClick(track) },
                        onFavoriteToggle = { viewModel.toggleFavorite(track) }
                    )
                }
            }
        }
    }
}

@Composable
fun ProfileTab() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .testTag("user_profile_tab"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Worshipper Profile",
            color = Color.White,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            modifier = Modifier
                .align(Alignment.Start)
                .padding(top = 20.dp, bottom = 24.dp)
        )

        // Main Circular Profile Image/Emblem
        Box(
            modifier = Modifier
                .size(100.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF8B5CF6), Color(0xFF4C1D95)),
                        radius = 160f
                    )
                )
                .border(2.dp, Color(0xFFC084FC), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "F",
                color = Color.White,
                fontSize = 44.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "Faith",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = "Everyday worshipper",
            color = Color(0xFFA78BFA),
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 2.dp)
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Interactive visual stat card row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF130E22))
                    .border(1.dp, Color(0x3FC084FC), RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Text("Daily Streak", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text("12 Days", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                }
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF130E22))
                    .border(1.dp, Color(0x3FC084FC), RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Text("Top Genre", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text("WORSHIP", color = Color(0xFFC084FC), fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Scripture Card Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0x1FC084FC), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F091F)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "“He put a new song in my mouth,\na hymn of praise to our God.”",
                    color = Color(0xFFE9D5FF),
                    fontSize = 14.sp,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                    fontFamily = FontFamily.Serif,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )
                Text(
                    text = "Psalm 40:3",
                    color = MaterialTheme.colorScheme.tertiary,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
        }
    }
}

@Composable
fun MiniPlayerBar(
    viewModel: TrackViewModel,
    onExpand: (Track) -> Unit
) {
    val track = viewModel.currentTrack ?: return
    val isPlaying = viewModel.isPlaying
    val currentSec = viewModel.playbackSeconds
    val totalSec = viewModel.parseDurationToSeconds(track.duration)
    val progress = if (totalSec > 0) currentSec.toFloat() / totalSec else 0f

    val startColor = parseHexColor(track.coverGradientStart)
    val endColor = parseHexColor(track.coverGradientEnd)

    val miniPlayerGradient = Brush.horizontalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.surface,
            startColor.copy(alpha = 0.16f),
            endColor.copy(alpha = 0.08f)
        )
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), startColor.copy(alpha = 0.40f))
                ),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onExpand(track) }
            .testTag("mini_player_bar"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(12.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(miniPlayerGradient)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
            // Slider / Progress bar at the top of the mini-player for responsive state display
            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    WorshipAlbumArt(
                        track = track,
                        modifier = Modifier.size(38.dp),
                        cornerRadius = 6.dp,
                        showTextOverlay = false
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = track.title,
                            color = MaterialTheme.colorScheme.onBackground,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = track.artist,
                            color = MaterialTheme.colorScheme.tertiary,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.togglePlayPause() },
                        modifier = Modifier.testTag("mini_play_pause")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.skipNext() },
                        modifier = Modifier.testTag("mini_skip_next")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Skip Next",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }
        }
    }
}

@Composable
fun AppBottomNavigationBar(
    selectedTab: Int,
    onTabSelect: (Int) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.primary,
        modifier = Modifier
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .testTag("app_navigation_bar")
    ) {
        val items = listOf(
            NavigationItem("Home", Icons.Filled.Home, Icons.Outlined.Home, 0),
            NavigationItem("Search", Icons.Filled.Search, Icons.Outlined.Search, 1),
            NavigationItem("Library", Icons.Filled.Favorite, Icons.Outlined.FavoriteBorder, 2),
            NavigationItem("Profile", Icons.Filled.Person, Icons.Outlined.Person, 3)
        )

        items.forEach { item ->
            val isSelected = selectedTab == item.index
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelect(item.index) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.label,
                        modifier = Modifier.size(24.dp)
                    )
                },
                label = { Text(item.label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    indicatorColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                modifier = Modifier.testTag("nav_item_${item.label.lowercase()}")
            )
        }
    }
}

data class NavigationItem(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val index: Int
)

@Composable
fun MoodIntentGrid(
    onCategoryClick: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            text = "Worship by Spiritual Intent",
            color = MaterialTheme.colorScheme.onBackground,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif
            )
        )
        Text(
            text = "Align your praise with your state of heart today.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MoodGridCard(
                title = "Peace & Stillness",
                subtitle = "For quiet rest & tranquility",
                category = "PEACE",
                icon = Icons.Default.Spa,
                gradientColors = listOf(Color(0xFF0F2642), Color(0xFF135E3E)), // Soft oceanic teal/green
                onClick = onCategoryClick,
                animationDelay = 0,
                modifier = Modifier.weight(1f)
            )
            MoodGridCard(
                title = "Adoration",
                subtitle = "Deep devotion & worship",
                category = "WORSHIP",
                icon = Icons.Default.SelfImprovement,
                gradientColors = listOf(Color(0xFF1E1338), Color(0xFF6732B0)), // Deep reverent purple/indigo
                onClick = onCategoryClick,
                animationDelay = 85,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MoodGridCard(
                title = "Praise & Joy",
                subtitle = "Celebrate His goodness",
                category = "PRAISE",
                icon = Icons.Default.WbSunny,
                gradientColors = listOf(Color(0xFF381C06), Color(0xFFBA6E05)), // Warm amber/orange candles
                onClick = onCategoryClick,
                animationDelay = 170,
                modifier = Modifier.weight(1f)
            )
            MoodGridCard(
                title = "All Offerings",
                subtitle = "Explore full catalog",
                category = "ALL",
                icon = Icons.Default.AutoStories,
                gradientColors = listOf(Color(0xFF0D0F1A), Color(0xFF3E4E63)), // Serene slate gray dawn
                onClick = onCategoryClick,
                animationDelay = 255,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun MoodGridCard(
    title: String,
    subtitle: String,
    category: String,
    icon: ImageVector,
    gradientColors: List<Color>,
    onClick: (String, String) -> Unit,
    animationDelay: Int,
    modifier: Modifier = Modifier
) {
    val alpha = remember { Animatable(0f) }
    val translationY = remember { Animatable(24f) } // subtle 24dp vertical guide

    LaunchedEffect(Unit) {
        delay(animationDelay.toLong())
        // Beautiful, calm fade-in easing curve
        alpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(
                durationMillis = 380,
                easing = { fraction ->
                    // Calm deceleration: 1 - (1 - f)^2
                    val f = 1f - fraction
                    1f - f * f
                }
            )
        )
    }

    LaunchedEffect(Unit) {
        delay(animationDelay.toLong())
        // Gentle spring animation with no overshoot / low bounce, supporting restfulness
        translationY.animateTo(
            targetValue = 0f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMediumLow
            )
        )
    }

    Card(
        modifier = modifier
            .height(105.dp)
            .graphicsLayer(
                alpha = alpha.value,
                translationY = translationY.value * 3f
            )
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick(category, if (category == "ALL") "All Offerings" else title) }
            .testTag("mood_grid_card_${category.lowercase()}"),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = gradientColors,
                        start = Offset(0f, 0f),
                        end = Offset(300f, 300f)
                    )
                )
                .border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(12.dp)
        ) {
            // Asymmetrical background visual icon glow
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.08f),
                modifier = Modifier
                    .size(68.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = 10.dp, y = 12.dp)
            )

            Column(
                modifier = Modifier.fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Column {
                    Text(
                        text = title,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Serif
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = subtitle,
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 11.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 1.dp)
                    )
                }
            }
        }
    }
}
