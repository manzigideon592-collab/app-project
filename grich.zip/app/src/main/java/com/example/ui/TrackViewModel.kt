package com.example.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.Track
import com.example.data.TrackRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class AppScreen {
    object Onboarding : AppScreen()
    object Main : AppScreen()
    data class PlaylistDetail(val category: String, val title: String) : AppScreen()
}

class TrackViewModel(
    application: Application,
    private val repository: TrackRepository
) : AndroidViewModel(application) {

    // Selected screen State
    var currentScreen by mutableStateOf<AppScreen>(AppScreen.Onboarding)
        private set

    // Selected bottom navigation tab
    var selectedTab by mutableIntStateOf(0)
    
    // Playback custom features resembling Spotify/Apple Music
    var playbackSpeed by mutableStateOf(1.0f) // 1.0f, 1.25f, 1.5f, 2.0f
    var selectedDevice by mutableStateOf("Built-in Speaker") // Active output destination
    var isKaraokeMode by mutableStateOf(false) // Toggle karaoke lyrics view

    // Current playing state
    var currentTrack by mutableStateOf<Track?>(null)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var playbackSeconds by mutableIntStateOf(0)
        private set

    // Active playlist being played
    private var activePlaylist = listOf<Track>()
    private var activePlaylistIndex = 0

    val currentPlaylist: List<Track> get() = activePlaylist
    val currentPlaylistIndex: Int get() = activePlaylistIndex

    // Search query state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Database Flows
    val allTracks: StateFlow<List<Track>> = repository.allTracks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteTracks: StateFlow<List<Track>> = repository.favoriteTracks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentlyPlayedTracks: StateFlow<List<Track>> = repository.recentlyPlayedTracks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered searches
    @Suppress("OPT_IN_USAGE")
    val searchResults: StateFlow<List<Track>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) {
                repository.allTracks
            } else {
                repository.searchTracks(query)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Playback Simulation Job
    private var playbackJob: Job? = null

    init {
        // Start playing the first track by default on clicking "Play" or "Shuffle Play" if none selected
        viewModelScope.launch {
            allTracks.collect { tracks ->
                if (currentTrack == null && tracks.isNotEmpty()) {
                    currentTrack = tracks.first()
                    activePlaylist = tracks
                    activePlaylistIndex = 0
                }
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        currentScreen = screen
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Toggle Favorite Action
    fun toggleFavorite(track: Track) {
        viewModelScope.launch {
            val newFav = !track.isFavorite
            repository.updateFavoriteStatus(track.id, newFav)
            // Synchronize current track state if updated
            if (currentTrack?.id == track.id) {
                currentTrack = currentTrack?.copy(isFavorite = newFav)
            }
        }
    }

    // Play explicit track
    fun playTrack(track: Track, playlist: List<Track> = emptyList()) {
        viewModelScope.launch {
            currentTrack = track
            playbackSeconds = 0
            isPlaying = true
            
            if (playlist.isNotEmpty()) {
                activePlaylist = playlist
                val idx = playlist.indexOfFirst { it.id == track.id }
                activePlaylistIndex = if (idx != -1) idx else 0
            } else {
                activePlaylist = listOf(track)
                activePlaylistIndex = 0
            }

            // Register in recently played
            repository.updateRecentlyPlayed(track.id, System.currentTimeMillis())
            startPlaybackTimer()
        }
    }

    fun togglePlayPause() {
        isPlaying = !isPlaying
        if (isPlaying) {
            startPlaybackTimer()
        } else {
            stopPlaybackTimer()
        }
    }

    fun skipNext() {
        if (activePlaylist.isNotEmpty()) {
            activePlaylistIndex = (activePlaylistIndex + 1) % activePlaylist.size
            playTrack(activePlaylist[activePlaylistIndex], activePlaylist)
        }
    }

    fun skipPrevious() {
        if (activePlaylist.isNotEmpty()) {
            activePlaylistIndex = if (activePlaylistIndex - 1 < 0) {
                activePlaylist.size - 1
            } else {
                activePlaylistIndex - 1
            }
            playTrack(activePlaylist[activePlaylistIndex], activePlaylist)
        }
    }

    fun seekTo(seconds: Int) {
        val maxSecValue = parseDurationToSeconds(currentTrack?.duration ?: "5:00")
        playbackSeconds = seconds.coerceIn(0, maxSecValue)
    }

    fun cyclePlaybackSpeed() {
        playbackSpeed = when (playbackSpeed) {
            1.0f -> 1.25f
            1.25f -> 1.5f
            1.5f -> 2.0f
            else -> 1.0f
        }
        // Restart timer with new delay if already playing
        if (isPlaying) {
            startPlaybackTimer()
        }
    }

    private fun startPlaybackTimer() {
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            while (isPlaying) {
                delay((1000L / playbackSpeed).toLong())
                currentTrack?.let { track ->
                    val maxSec = parseDurationToSeconds(track.duration)
                    if (playbackSeconds < maxSec) {
                        playbackSeconds++
                    } else {
                        // End of song -> automatic skip next
                        skipNext()
                    }
                }
            }
        }
    }

    private fun stopPlaybackTimer() {
        playbackJob?.cancel()
        playbackJob = null
    }

    fun parseDurationToSeconds(durationString: String): Int {
        val parts = durationString.split(":")
        if (parts.size == 2) {
            val minutes = parts[0].toIntOrNull() ?: 0
            val seconds = parts[1].toIntOrNull() ?: 0
            return minutes * 60 + seconds
        }
        return 300 // 5m default
    }

    fun formatSecondsToDuration(seconds: Int): String {
        val m = seconds / 60
        val s = seconds % 60
        return String.format("%d:%02d", m, s)
    }

    override fun onCleared() {
        super.onCleared()
        stopPlaybackTimer()
    }
}

class TrackViewModelFactory(
    private val application: Application,
    private val repository: TrackRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TrackViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return TrackViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
