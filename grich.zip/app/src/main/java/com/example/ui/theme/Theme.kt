package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AltarGold,              // Serene candlelit gold/champagne reflecting divine radiance
    secondary = CelestialBlue,        // Tranquil twilight indigo evoking cosmic night and peace
    tertiary = LightAuraPurple,       // Soft amethyst aura representing grace
    background = SacredMidnight,      // Deep, serene dark void background
    surface = SanctuaryVelvet,        // Comforting, low-fatigue velvet surface cards
    onPrimary = Color(0xFF1A1200),    // Dark golden-charcoal contrast for primary text
    onSecondary = Color(0xFFFFFFFF),
    onTertiary = Color(0xFF0F0025),
    onBackground = GraceWhite,        // Soft off-white linen text
    onSurface = GraceWhite,
    surfaceVariant = SanctuaryMist,   // Secondary card background levels
    onSurfaceVariant = IncenseAsh     // Muted incense ash sub-text
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force signature dark branding for GRICH worship
    dynamicColor: Boolean = false, // Force custom branding colors
    content: @Composable () -> Unit,
) {
    val colorScheme = DarkColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
