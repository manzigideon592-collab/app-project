package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Spiritual Calm Theme Color Palette - "Sacred Celestial / Candlelit Sanctuary"
val SacredMidnight = Color(0xFF040208)      // Extremely deep, serene dark void with a faint spiritual undertone
val AltarGold = Color(0xFFF3D295)            // Warm, serene candlelit/champagne gold reflecting divine radiance
val CelestialBlue = Color(0xFF818CF8)        // Radiant twilight indigo, evoking night skies and tranquil depths
val LightAuraPurple = Color(0xFFC084FC)      // Soft lilac aura representing grace and spiritual guidance
val SanctuaryVelvet = Color(0xFF100B1D)      // Comforting deep-surface cards with a quiet, low-fatigue velvet feel
val SanctuaryMist = Color(0xFF1A132C)        // Hover or secondary card level surface

// Text and feedback ink colors
val GraceWhite = Color(0xFFF8F5FC)           // Off-white linen color for main text, highly clean and calm
val IncenseAsh = Color(0xFFC7BED3)           // Soft muted slate text for captions, labels, and subheadings
val CandleGlow = Color(0xFFFCD34D)           // Warm glowing amber/yellow for secondary accents, icons, and star highlights
val DivineCrimson = Color(0xFFF87171)        // Gentle dark blood Red for destructive warnings
