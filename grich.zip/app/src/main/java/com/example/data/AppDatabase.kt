package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Track::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun trackDao(): TrackDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "grich_database"
                )
                .addCallback(AppDatabaseCallback(scope))
                .build()
                @Suppress("LocalVariableName")
                val _instance = instance
                INSTANCE = _instance
                _instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.trackDao())
                }
            }
        }

        suspend fun populateDatabase(trackDao: TrackDao) {
            val initialTracks = listOf(
                Track(
                    id = 1,
                    title = "Goodness of God",
                    artist = "CeCe Winans",
                    duration = "5:03",
                    category = "WORSHIP",
                    isFavorite = true,
                    recentlyPlayedAt = System.currentTimeMillis() - 600000,
                    lyrics = "I love You, Lord, for Your mercy never fails me.\nAll my days, I've been held in Your hands.\nFrom the moment that I wake up until I lay my head,\nI will sing of the goodness of God.",
                    description = "A powerful declaration of God's faithfulness and endless love. CeCe Winans delivers an anointed, heartfelt performance that leads listeners deep into gratitude.",
                    coverGradientStart = "FF7F3DFF", // deep violet
                    coverGradientEnd = "FF8F43EE",   // purple light
                    customIconType = "spotlight"
                ),
                Track(
                    id = 2,
                    title = "Way Maker",
                    artist = "Sinach",
                    duration = "4:45",
                    category = "WORSHIP",
                    isFavorite = false,
                    recentlyPlayedAt = System.currentTimeMillis() - 1200000,
                    lyrics = "You are here, moving in our midst; I worship You, I worship You.\nYou are here, working in this place; I worship You, I worship You.\n\nWay Maker, Miracle Worker, Promise Keeper, Light in the darkness,\nMy God, that is who You are.",
                    description = "An internationally acclaimed worship anthem written by gospel singer Sinach. It celebrates God as our constant guide, light, and promise keeper.",
                    coverGradientStart = "FF4F83FF", // bright blue
                    coverGradientEnd = "FF33C2FF",   // light cyan
                    customIconType = "cross_ring"
                ),
                Track(
                    id = 3,
                    title = "Gratitude",
                    artist = "Brandon Lake",
                    duration = "5:12",
                    category = "PRAISE",
                    isFavorite = false,
                    recentlyPlayedAt = System.currentTimeMillis() - 1800000,
                    lyrics = "All my words are few, but I have this song that I can sing for You.\nI throw up my hands and praise You again and again.\n\n'Cause all that I have is a hallelujah, hallelujah.\nLord, is that enough?",
                    description = "A beautifully raw and honest worship song. Brandon Lake invites us to offer our praise even when we feel we have nothing else to give.",
                    coverGradientStart = "FFFD7E14", // amber/orange
                    coverGradientEnd = "FFF35B04",   // vivid orange
                    customIconType = "vertical_beams"
                ),
                Track(
                    id = 4,
                    title = "10,000 Reasons (Bless The Lord)",
                    artist = "Matt Redman",
                    duration = "4:21",
                    category = "PRAISE",
                    isFavorite = false,
                    recentlyPlayedAt = null,
                    lyrics = "Bless the Lord, O my soul, O my soul;\nWorship His holy name.\nSing like never before, O my soul;\nI'll worship Your holy name.",
                    description = "An award-winning classic written by Matt Redman and Jonas Myrin, exalting God's infinite merit for worship through ten thousand reasons.",
                    coverGradientStart = "FF7F3DFF", // deep violet
                    coverGradientEnd = "FF00F5D4",   // electric teal
                    customIconType = "cross_ring"
                ),
                Track(
                    id = 5,
                    title = "Oceans (Where Feet May Fail)",
                    artist = "Hillsong UNITED",
                    duration = "4:55",
                    category = "PEACE",
                    isFavorite = true,
                    recentlyPlayedAt = null,
                    lyrics = "You call me out upon the waters, the great unknown where feet may fail.\nAnd there I find You in the mystery; in oceans deep my faith will stand.\n\nSpirit lead me where my trust is without borders,\nLet me walk upon the waters wherever You would call me.",
                    description = "An iconic ocean-wide journey exploring faith, radical trust, and stepping out into the depth of God's call.",
                    coverGradientStart = "FF1C355E", // deep sea blue
                    coverGradientEnd = "FF198754",   // ocean green
                    customIconType = "water_ripple"
                ),
                Track(
                    id = 6,
                    title = "How Great Is Our God",
                    artist = "Chris Tomlin",
                    duration = "4:32",
                    category = "PRAISE",
                    isFavorite = false,
                    recentlyPlayedAt = null,
                    lyrics = "The splendor of a King, clothed in majesty;\nLet all the earth rejoice, all the earth rejoice.\nHe wraps Himself in light, and darkness tries to hide,\nAnd trembles at His voice, trembles at His voice.\n\nHow great is our God! Sing with me, how great is our God!",
                    description = "One of the most widely sung modern hymns of all time. Written by Chris Tomlin, it exalts the splendor and eternal majesty of our Creator.",
                    coverGradientStart = "FF343A40", // slate gray
                    coverGradientEnd = "FFE83E8C",   // magenta
                    customIconType = "sun_rays"
                ),
                Track(
                    id = 7,
                    title = "Build My Life",
                    artist = "Pat Barrett",
                    duration = "5:05",
                    category = "PEACE",
                    isFavorite = false,
                    recentlyPlayedAt = null,
                    lyrics = "Worthy of every song we could ever sing;\nWorthy of all the praise we could ever bring;\nWorthy of every breath we could ever breathe;\nWe live for You.\n\nJesus, the name above every other name.",
                    description = "A worship masterpiece focusing on building our daily lives upon the solid foundation of Jesus' secure foundation and incredible love.",
                    coverGradientStart = "FF0D6EFD", // vibrant blue
                    coverGradientEnd = "FF6610F2",   // indigo
                    customIconType = "cross_ring"
                )
            )
            trackDao.insertAll(initialTracks)
        }
    }
}
