package com.example.data

import kotlinx.coroutines.flow.Flow

class TrackRepository(private val trackDao: TrackDao) {
    val allTracks: Flow<List<Track>> = trackDao.getAllTracks()
    val favoriteTracks: Flow<List<Track>> = trackDao.getFavoriteTracks()
    val recentlyPlayedTracks: Flow<List<Track>> = trackDao.getRecentlyPlayedTracks()

    fun getTrackById(id: Int): Flow<Track?> = trackDao.getTrackById(id)

    suspend fun updateFavoriteStatus(id: Int, isFavorite: Boolean) {
        trackDao.updateFavoriteStatus(id, isFavorite)
    }

    suspend fun updateRecentlyPlayed(id: Int, timestamp: Long?) {
        trackDao.updateRecentlyPlayed(id, timestamp)
    }

    fun searchTracks(query: String): Flow<List<Track>> = trackDao.searchTracks(query)
}
