package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class Track(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val artist: String,
    val duration: String,
    val category: String, // e.g. "WORSHIP", "PRAISE", "PEACE"
    val isFavorite: Boolean = false,
    val recentlyPlayedAt: Long? = null,
    val lyrics: String = "",
    val description: String = "",
    val coverGradientStart: String, // Hex string for visual gradient, e.g. "FF7F3DFF"
    val coverGradientEnd: String,   // Hex string for visual gradient, e.g. "FF8F43EE"
    val customIconType: String = "" // Special icon type e.g. "cross_ring" or "spotlight"
)
