package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.data.AppDatabase
import com.example.data.TrackRepository
import com.example.ui.AppScreen
import com.example.ui.TrackViewModel
import com.example.ui.TrackViewModelFactory
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PlayerScreen
import com.example.ui.screens.PlaylistScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Room Database
        val database = AppDatabase.getDatabase(this, lifecycleScope)
        val repository = TrackRepository(database.trackDao())

        // Setup ViewModel
        val viewModel = ViewModelProvider(
            this,
            TrackViewModelFactory(application, repository)
        )[TrackViewModel::class.java]

        setContent {
            MyApplicationTheme {
                var isPlayerExpanded by remember { mutableStateOf(false) }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF030107))
                ) {
                    // Coordindate primary screens via ViewModel reactive state
                    when (val screen = viewModel.currentScreen) {
                        is AppScreen.Onboarding -> {
                            OnboardingScreen(
                                onExploreClick = { viewModel.navigateTo(AppScreen.Main) }
                            )
                        }
                        is AppScreen.Main -> {
                            HomeScreen(
                                viewModel = viewModel,
                                onPlaylistClick = { category, title ->
                                    viewModel.navigateTo(AppScreen.PlaylistDetail(category, title))
                                },
                                onOpenPlayer = { isPlayerExpanded = true }
                            )
                        }
                        is AppScreen.PlaylistDetail -> {
                            PlaylistScreen(
                                viewModel = viewModel,
                                category = screen.category,
                                playlistTitle = screen.title,
                                onBackClick = { viewModel.navigateTo(AppScreen.Main) }
                            )
                        }
                    }

                    // Sliding full-player overlay so that background audio states remain active
                    AnimatedVisibility(
                        visible = isPlayerExpanded,
                        enter = slideInVertically(initialOffsetY = { it }),
                        exit = slideOutVertically(targetOffsetY = { it })
                    ) {
                        PlayerScreen(
                            viewModel = viewModel,
                            onBackClick = { isPlayerExpanded = false }
                        )
                    }
                }
            }
        }
    }
}

